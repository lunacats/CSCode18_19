from time import sleep

def execute(json):
    code = json[12:-2]

    commands = code.split()

    retVal = "Program Start:"
    for command in commands:
        if command[0:4].lower() == "stop":
            retVal += sendJson("{'c':4}")
        elif command[0:5].lower() == "sleep":
            sleep(float(command[6:-1]))
            retVal += "Sleeping";
        else:
            retVal += "invalid command:" + command
        
        
    
    
    return "{\"R\":\""+str(retVal)+"\"}"


def sendJson(code):
    return code + " not implemented"
