from RobotCommunication import *
from time import sleep

def execute(json):
    code = json[12:-2]

    commands = code.split()

    retVal = "Program Start:"
    for command in commands:
        if command[0:7].lower() == "forward":
            jStr = "{'c':0, 'p':"+command[8:-1]+"}"
            print jStr
            print send_json(jStr)

            retVal += "Forward "
        elif command[0:4].lower() == "back":
            send_json("{'c':1, 'p':"+command[5:-1]+"}")
            retVal += "Back "
        elif command[0:4].lower() == "left":
            send_json("{'c':2, 'p':"+command[5:-1]+"}")
            retVal += "Left "
        elif command[0:4].lower() == "right":
            send_json("{'c':3, 'p':"+command[5:-1]+"}")
            retVal += "Right "
        elif command[0:4].lower() == "stop":
            send_json("{'c':4}")
            retVal += "Stopped "
        elif command[0:5].lower() == "sleep":
            sleep(float(command[6:-1]))
            retVal += "Sleeping ";
        else:
            retVal += "invalid command: [" + command +"] "
        
        
    
    
    return "{\"R\":\""+str(retVal)+"\"}"
