from RobotCommunication import *
import PixyFollowSig
from time import sleep
import json


# The height that the picture should be at the target position
posHeight = 60
# The allowed variation for the height
vary = 20

if __name__ == '__main__':
    PixyFollowSig.startup()
    
    while True:
        dataString = PixyFollowSig.getSig()

        data = json.loads(dataString)

        if data["C"] == 0:
            stop()

        for i in range(0,data["C"]):
            if data["S0"] == 1:
                print "getting height"
            if data["H0"] > posHeight + vary:
                back(10);
                "Going forward:" + str(data["H0"])
            elif data["H0"] < posHeight - vary:
                forward(10)
                "Going back:" + str(data["H0"])
            else:
                stop()
                "We made it:" + str(data["H0"])

            sleep(0.05)
