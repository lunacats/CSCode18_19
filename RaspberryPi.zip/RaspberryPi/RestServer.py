from flask import Flask
from RobotCommunication import *
import GetPixyInfo
from time import sleep
import ExecuteRemoteCode

def shutdown_server():
    func = request.environ.get('werkzeug.server.shutdown')
    if func is None:
        raise RuntimeError('Not running with the Werkzeug Server')
    func()

app = Flask(__name__)

# {'cmd': '0', 'power': 50}
@app.route('/cmd/<string:data>', methods=['GET'])
def get_task(data):

    print "Got:\t"+data;
    response = ""
    if data[1:6] == "'c':7":
        response = ExecuteRemoteCode.execute(data)
    elif data == "{'c':5}":
        response = GetPixyInfo.getSig()
    else:
	if data == "{'s':0}":
	    shutdown_server()
            response = 'Shutting Down'
        else:
            response = send_json(data)

    print "Sending:\t" + response
    return response;


if __name__ == '__main__':
    GetPixyInfo.startup()
    app.run(host = '0.0.0.0')

@app.route('/shutdown/<string:data>', methods=['GET'])
def shutdown():
    shutdown_server()
    return 'Server shutting down...'
